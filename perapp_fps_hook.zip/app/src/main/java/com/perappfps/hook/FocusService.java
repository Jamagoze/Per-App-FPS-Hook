package com.perappfps.hook;

import android.accessibilityservice.AccessibilityService;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;

import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FocusService extends AccessibilityService {
    private static final String CMD_PREFIX = "sh /data/adb/modules/perapp_fps/focus.sh ";
    private static final String CMD_SUFFIX = " >/dev/null 2>&1\n";

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private String last = "";
    private Process su;
    private OutputStream out;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = event.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (pkg.equals(last) || ignored(pkg)) return;
        last = pkg;
        send(pkg);
    }

    // Skip system UI, the keyboard and ourselves, so they don't flip the refresh rate
    private boolean ignored(String pkg) {
        if (!pkg.matches("[A-Za-z0-9_.]+")) return true;
        if (pkg.equals(getPackageName())) return true;
        if (pkg.equals("com.android.systemui") || pkg.equals("android")) return true;
        String ime = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        if (ime != null && ime.startsWith(pkg + "/")) return true;
        return false;
    }

    // One long-lived root shell, so we don't spawn su on every app switch
    private void send(final String pkg) {
        exec.execute(() -> {
            for (int i = 0; i < 2; i++) {
                try {
                    if (su == null) {
                        su = Runtime.getRuntime().exec("su");
                        out = su.getOutputStream();
                    }
                    out.write((CMD_PREFIX + pkg + CMD_SUFFIX).getBytes());
                    out.flush();
                    return;
                } catch (Exception e) {
                    closeSu();
                }
            }
        });
    }

    private void closeSu() {
        try { if (out != null) out.close(); } catch (Exception ignored) { }
        try { if (su != null) su.destroy(); } catch (Exception ignored) { }
        su = null;
        out = null;
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        exec.execute(this::closeSu);
        exec.shutdown();
        super.onDestroy();
    }
}
